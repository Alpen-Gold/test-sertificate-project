function MenPage() {
  return <p>Men page </p>;
}

export default MenPage;
